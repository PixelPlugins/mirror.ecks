const http = require('http');
const { spawn } = require('child_process');

var exec = require('child_process').exec;
function execute(command, callback){
    exec(command, function(error, stdout, stderr){ callback(stdout); });
};

http.createServer(function(req, res){
	res.writeHead(200, {'Access-Control-Allow-Origin': '*'});
	var args = req.url.substring(1).split('~');
	var cmd = args[0];
	
	if(cmd=='install'){
		execute('bin\\Plexicraft.StoreInstall.exe "' + args[1] + '" "' + args[2] + '"', function(sto){res.write(sto);res.end();});
	}
	
	if(cmd=='open'){
		execute('bin\\Plexicraft.RunAPP.exe ' + args[1] + ' "' + args[2] + '"', function(sto){res.write(sto);res.end();});
	}
	
	if(cmd == 'regedit'){
		execute('bin\\Plexicraft.RegistryAPI.WebInterface.exe '+args[1]+' '+args[2]+' '+args[3], function(sto){res.write(sto);res.end();});
	}
}).listen(9111);